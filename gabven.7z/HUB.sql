declare
 
  v_cur        INTEGER;
  v_col_cnt    INTEGER;
  v_status     INTEGER;
  v_desc       DBMS_SQL.DESC_TAB2;

  v_val        VARCHAR2(4000);
  v_line       VARCHAR2(4000);
  v_clean      VARCHAR2(4000);
  v_encoding   VARCHAR2(4000);
  v_header     VARCHAR2(30);
  v_rowcount   INTEGER := 0;
  v_file       UTL_FILE.FILE_TYPE;
  v_filename   VARCHAR2(100);  
  v_param1     varchar2(8) := '20260130';
  
  CURSOR c0 IS SELECT hub.* FROM NOM_NOTIFY_TABLES hub WHERE IS_VALID = 'Y' AND hub.template_name = 'SPB4';
    
BEGIN
    
FOR i IN c0
LOOP
        v_filename := i.file_name || to_char(sysdate, 'YYYYMMDD') || i.extension;
        v_file := UTL_FILE.FOPEN('XTERN_DATA_DIR', v_filename, 'W', 32767);

        v_cur := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(v_cur, i.query_str, DBMS_SQL.NATIVE);
        DBMS_SQL.BIND_VARIABLE(v_cur, ':b1', v_param1);
        DBMS_SQL.DESCRIBE_COLUMNS2(v_cur, v_col_cnt, v_desc);

        FOR c IN 1 .. v_col_cnt LOOP
          DBMS_SQL.DEFINE_COLUMN(v_cur, c, v_val, 4000);
        END LOOP;

    v_status := DBMS_SQL.EXECUTE(v_cur);
  
    EXECUTE IMMEDIATE 'truncate table stage.global_file_table';

    LOOP EXIT WHEN DBMS_SQL.FETCH_ROWS(v_cur) = 0;
  
    v_rowcount := v_rowcount + 1;
    v_line := NULL;

          FOR c IN 1 .. v_col_cnt 
          LOOP
            DBMS_SQL.COLUMN_VALUE(v_cur, c, v_val);
            IF c > 1 THEN v_line := v_line || i.delimiter; END IF;
            v_line := v_line || NVL(v_val, '');
          END LOOP;    

          INSERT INTO stage.global_file_table (V_TEXT) VALUES (SUBSTR(v_line, 1, 4000));
    
    END LOOP;

        v_header := lpad(v_rowcount, 8, '0') || i.delimiter || i.notify_tag || i.delimiter || i.template_name || i.delimiter || null || i.delimiter || null || i.delimiter || i.const_1 || i.delimiter || i.const_2;
        UTL_FILE.PUT_LINE(v_file, SUBSTR(v_header, 1, 32767));
  
        FOR r IN (SELECT v_text FROM stage.global_file_table ORDER BY 1) 
        LOOP
             v_clean := REGEXP_REPLACE(r.v_text, '[^[:print:]]', '');
             v_encoding := CONVERT(v_clean, 'CL8MSWIN1251');
             UTL_FILE.PUT_LINE(v_file, v_encoding);
        END LOOP;
        
        pck_notify_message.insert_into_log(loaded_tables_log_seq.nextval, v_filename, i.template_name, sysdate, v_rowcount, v_rowcount, 'T', trim(sysdate), 'OK', 'HUB', sysdate);
  
    commit;  
    END LOOP;
    
    DBMS_SQL.CLOSE_CURSOR(v_cur);  
    UTL_FILE.FCLOSE(v_file);

    EXCEPTION WHEN OTHERS THEN IF DBMS_SQL.IS_OPEN(v_cur) THEN DBMS_SQL.CLOSE_CURSOR(v_cur); END IF;
    RAISE;
    
end;
----------------------------------------------
declare
 
  v_cur        INTEGER;
  v_col_cnt    INTEGER;
  v_status     INTEGER;
  v_desc       DBMS_SQL.DESC_TAB2;

  v_val        VARCHAR2(4000);
  v_line       VARCHAR2(4000);
  v_clean      VARCHAR2(4000);
  v_encoding   VARCHAR2(4000);
  v_header     VARCHAR2(30);
  v_rowcount   INTEGER := 0;
  v_file       UTL_FILE.FILE_TYPE;
  v_filename   VARCHAR2(100) := 'export_' || TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS') || '.txt';
  
  CURSOR c0 IS SELECT hub.* FROM NOM_NOTIFY_TABLES hub WHERE IS_VALID = 'Y' AND hub.template_name = 'SPB1';
    
BEGIN
    
FOR i IN c0
LOOP
        v_filename := i.file_name || to_char(sysdate, 'YYYYMMDD') || i.extension;
        v_file := UTL_FILE.FOPEN('XTERN_DATA_DIR', v_filename, 'W', 32767);

        v_cur := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(v_cur, i.query_str, DBMS_SQL.NATIVE);
        DBMS_SQL.BIND_VARIABLE(v_cur, ':b1', '%' || i.var_1 || '%');
        DBMS_SQL.DESCRIBE_COLUMNS2(v_cur, v_col_cnt, v_desc);

        FOR c IN 1 .. v_col_cnt LOOP
          DBMS_SQL.DEFINE_COLUMN(v_cur, c, v_val, 4000);
        END LOOP;

    v_status := DBMS_SQL.EXECUTE(v_cur);
  
    EXECUTE IMMEDIATE 'truncate table stage.global_file_table';

    LOOP EXIT WHEN DBMS_SQL.FETCH_ROWS(v_cur) = 0;
  
    v_rowcount := v_rowcount + 1;
    v_line := NULL;

          FOR c IN 1 .. v_col_cnt 
          LOOP
            DBMS_SQL.COLUMN_VALUE(v_cur, c, v_val);
            IF c > 1 THEN v_line := v_line || i.delimiter; END IF;
            v_line := v_line || NVL(v_val, '');
          END LOOP;    

          INSERT INTO stage.global_file_table (V_TEXT) VALUES (SUBSTR(v_line, 1, 4000));
    
    END LOOP;

        DBMS_SQL.CLOSE_CURSOR(v_cur);  
  
        v_header := lpad(v_rowcount, 8, '0') || i.delimiter || i.notify_tag || i.delimiter || i.template_name || i.delimiter || null || i.delimiter || null || i.delimiter || i.const_1 || i.delimiter || i.const_2;
        UTL_FILE.PUT_LINE(v_file, SUBSTR(v_header, 1, 32767));
  
        FOR r IN (SELECT v_text FROM stage.global_file_table ORDER BY 1) 
        LOOP
             v_clean := REGEXP_REPLACE(r.v_text, '[^[:print:]]', '');
             v_encoding := CONVERT(v_clean, 'CL8MSWIN1251');
             UTL_FILE.PUT_LINE(v_file, v_encoding);
        END LOOP;
        
        pck_notify_message.insert_into_log(loaded_tables_log_seq.nextval, v_filename, i.template_name, sysdate, v_rowcount, v_rowcount, 'T', trim(sysdate), 'OK', 'HUB', sysdate);
  
    commit;
  
    UTL_FILE.FCLOSE(v_file);
  
    END LOOP;

    EXCEPTION WHEN OTHERS THEN IF DBMS_SQL.IS_OPEN(v_cur) THEN DBMS_SQL.CLOSE_CURSOR(v_cur); END IF;
    RAISE;
    
end;

------------------------------------------------------------------------------------------
create table NOM_NOTIFY_TABLES
(
  notify_tag    VARCHAR2(3),
  template_name VARCHAR2(70),
  var_1         VARCHAR2(10),
  var_2         VARCHAR2(10),
  const_1       NUMBER(1),
  const_2       NUMBER(1),
  delimiter     VARCHAR2(1),
  is_valid      VARCHAR2(1),
  query_str     CLOB,
  file_name     VARCHAR2(34),
  extension     VARCHAR2(7)
)

-----------------------------------------------------

create table GLOBAL_FILE_TABLE
(
  v_text VARCHAR2(4000)
)

