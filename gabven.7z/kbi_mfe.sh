#!/bin/sh
 
NOW=$(date +"%d")
curr_date="`date +%Y-%m-%d`"
mid_day=$(date +%p)

EFD=`cat /u04/odi_get_scripts/effective_date.txt`
EFD="${EFD:0:10}"
PED=`cat /u04/odi_get_scripts/prev_eff_date.txt`
PFD="${PFD:0:10}"

EFF_DATE_TMP=`cat /export/home/odioper/effective_date.txt`
eff_date_calculated="${EFF_DATE_TMP:0:10}"

eff_date=${EFD:-$eff_date_calculated}

if expr "${EFD}" "<=" "${PED}" > /dev/null; then 

echo -e "Someting is wrong with EFF_DATE !!!" >> ${log}
echo -e "Aborting ....." >> ${log}
echo -e "Current EFF_DATE --->  ${EFD}" >> ${log}
echo -e "Prev EFF_DATE --->  ${PED}" >> ${log}

echo -e "Someting is wrong with EFF_DATE !!!"
echo -e "Aborting ....."
echo -e "Current EFF_DATE --->  ${EFD}"
echo -e "Prev EFF_DATE --->  ${PED}"

exit 10

fi

cd /export/home/oracle/admin/odi_datastage/scripts

if [ $mid_day == "AM" ];  
then  

echo "true condition" 

sh run_kbi.sh tabnomkl cics60 $curr_date -1 Y

sleep 34

sh run_kbi.sh txtnomkl cics60 $curr_date -1 Y

else

echo "false condition"

fi 

echo "####################################"  
echo "created by ZZhelev 2024";